package com.example.news;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Displays a list of articles in recyler view
 * Provides a mechanism to handling item clic events
 */
public class MainArticleAdapter extends RecyclerView.Adapter<MainArticleAdapter.ViewHolder> {
    // List of articles to display in the RecyclerView
    private final List<Article> articleArrayList;

    // Listener to handle item click events in the RecyclerView
    private OnRecyclerViewItemClickListener onRecyclerViewItemClickListener;

    // Constructor that initializes the articleArrayList with the provided list of articles
    public MainArticleAdapter(List<Article> articleArrayList) {
        this.articleArrayList = articleArrayList;
    }

    /**
     * Called when RecyclerView needs a new instance of ViewHolder for a new item
     *
     * @param viewGroup   The ViewGroup into which the new View will be added after it is bound to
     *                 an adapter position.
     * @param i The view type of the new View.
     * @return a new instance of ViewHolder
     */
    @NonNull
    @Override
    public MainArticleAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_main_article_adapter, viewGroup, false);
        return new MainArticleAdapter.ViewHolder(view);
    }

    /**
     * Binds the data from article object to corresponding ViewHolder
     *
     * @param viewHolder   The ViewHolder which should be updated to represent the contents of the
     *                 item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull MainArticleAdapter.ViewHolder viewHolder, int position) {
        // gets the article at the current posistion in the list
        final Article articleModel = articleArrayList.get(position);
        // Set the title of the article if it is not empty
        if (!TextUtils.isEmpty(articleModel.getTitle())) {
            viewHolder.titleText.setText(articleModel.getTitle());
        }
        // Set the tag of the parent view to the article model for later retrieval
        viewHolder.articleAdapterParentLinear.setTag(articleModel);
    }

    /**
     * Gets size of the articleArrayList which is the list of articles that the adapter
     * is displaying
     * @return size of article array list
     */
    @Override
    public int getItemCount() {
        return articleArrayList.size();
    }

    /**
     * Holds the views of each item in the recycler view
     */
    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView titleText;
        private final LinearLayout articleAdapterParentLinear;

        /**
         * Define a ViewHolder that stores references to the views that represent
         * each item in the RecyclerView
         *
         * @param view view used to instantiate the ViewHolder object
         */
        ViewHolder(View view) {
            super(view);
            titleText = view.findViewById(R.id.article_adapter_tv_title);
            articleAdapterParentLinear = view.findViewById(R.id.article_adapter_ll_parent);
            // Set a click listener on the parent linear layout to detect clicks on the item
            articleAdapterParentLinear.setOnClickListener(view1 -> {
                if (onRecyclerViewItemClickListener != null) {
                    // Call the onItemClick method of the listener with the clicked view as the parameter
                    onRecyclerViewItemClickListener.onItemClick(view1);
                }
            });

            articleAdapterParentLinear.setOnClickListener(view12 -> {
                if (onRecyclerViewItemClickListener != null) {
                    onRecyclerViewItemClickListener.onItemClick(view12);
                }
            });
        }
    }

    /**
     * sets the OnRecyclerViewItemClickListener interface object to the instance variable
     * @param onRecyclerViewItemClickListener instance of the interface OnRecyclerViewItemClickListener
     */
    public void setOnRecyclerViewItemClickListener(OnRecyclerViewItemClickListener onRecyclerViewItemClickListener) {
        this.onRecyclerViewItemClickListener = onRecyclerViewItemClickListener;
    }

}