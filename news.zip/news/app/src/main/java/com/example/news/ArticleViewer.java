package com.example.news;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * class is responsible for displaying a webview of each article
 */
public class ArticleViewer extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Calls the parent class's onCreate method and passes it to the saved instance state
        super.onCreate(savedInstanceState);
        setContentView(R.layout.article_viewer);
        // Get the URL of the article to display from the intent that started this activity
        final String url = getIntent().getStringExtra("url");
        WebView webView = findViewById(R.id.web_view);
        // Load the article's URL into the WebView object
        webView.loadUrl(url);
    }
}
