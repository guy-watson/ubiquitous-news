package com.example.news;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Defines a http request for the api using retrofits annotations
 *
 * Takes 4 questy parameters, "q" is the search term and this is modified in the main activity
 * to search for articles of different teams.
 */
public interface ApiInterface {
    @GET("everything")
    Call<ResponseModel> getLatestNews(@Query("language") String language, @Query("sortBy") String sort, @Query("q") String q, @Query("apiKey") String apiKey);

}
