package com.example.news;

import android.view.View;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(View view);

    void onCheckedChanged(View view);
}
