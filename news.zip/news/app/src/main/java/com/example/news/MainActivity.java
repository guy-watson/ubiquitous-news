package com.example.news;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity implements OnRecyclerViewItemClickListener {

    private static final String API_KEY = "da8d091153b24b02be396b1e195d8a90";
    private static String Q = "F1";
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String THEMESWITCH = "themeSwitch";
    private SwitchCompat themeSwitch;
    private boolean switchOnOff;

    /**
     * Creates main activity, inflates the layout, sets event listeners and starts background tasks
     *
     * @param savedInstanceState Contains the activity's previously saved state
     */
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // initialise views and set up recycler view
        setContentView(R.layout.activity_main);

        themeSwitch = findViewById(R.id.themeSwitch);
        Button saveButton = findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(view -> saveData());

        final RecyclerView mainRecycler = findViewById(R.id.activity_main_rv);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mainRecycler.setLayoutManager(linearLayoutManager);

        // initialises api service
        final ApiInterface apiService =
                ApiClient.getClient().create(ApiInterface.class);

        // sets up the switch to toggle themes
        themeSwitch.setOnCheckedChangeListener((compoundButton, isChecked) -> {
            if (isChecked) {
                getWindow().getDecorView().setBackgroundColor(Color.BLACK); // dark theme
                mainRecycler.setBackgroundColor(Color.BLACK);
            } else {
                getWindow().getDecorView().setBackgroundColor(Color.WHITE); // light theme
                mainRecycler.setBackgroundColor(Color.WHITE);
            }
        });

        // api call to retrieve popular articles
        Call<ResponseModel> call = apiService.getLatestNews("en", "popularity", Q, API_KEY);

        // load saved data and update views
        // TODO: change update view name
        loadData();
        updateViews();

        // Enqueue the API call and handle the response using a callback
        call.enqueue(new Callback<ResponseModel>() {


            /**
             * on response
             * @param call
             * call
             *
             * @param response
             * response
             */
            @Override
            public void onResponse(@NonNull Call<ResponseModel> call, @NonNull Response<ResponseModel> response) {
                assert response.body() != null;
                if (response.body().getStatus().equals("ok")) {
                    List<Article> articleList = response.body().getArticles();
                    if (articleList.size() > 0) {

                        final MainArticleAdapter mainArticleAdapter = new MainArticleAdapter(articleList);
                        mainArticleAdapter.setOnRecyclerViewItemClickListener(MainActivity.this);
                        mainRecycler.setAdapter(mainArticleAdapter);


                    }
                }
            }

            /**
             * handles failed api response
             *
             * @param call the api call that was made
             * @param t the error
             */
            @Override
            public void onFailure(@NonNull Call<ResponseModel> call, @NonNull Throwable t) {
                Log.e("API CALL IS NOT WORKING", t.toString());
            }
        });
    }

    /**
     * saves the state of the theme switch
     */
    public void saveData() {
        // Get the SharedPreferences instance
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Store the current value of the "themeSwitch" Switch in the SharedPreferences instance
        editor.putBoolean(THEMESWITCH, themeSwitch.isChecked());

        editor.apply();
    }

    /**
     * loads the save state of the theme switch
     */
    public void loadData() {
        // Get the SharedPreferences instance
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        // Retrieve the boolean value of THEMESWITCH from the SharedPreferences instance
        // and store it in the switchOnOff variable.
        switchOnOff = sharedPreferences.getBoolean(THEMESWITCH, false);

    }

    /**
     * sets the state of the switch based on switchOnOff variable
     */
    public void updateViews() {
        themeSwitch.setChecked(switchOnOff);
    }

    /**
     * Called when options are created then inflates the dropdown menu
     *
     * @param menu the menu object to populate
     * @return true to indicate that the menu has been created
     *
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.dropdown, menu);
        return true;
    }

    /**
     * Called when an item in the options menu is selected. Checks the items id and then changes
     * the article url using the "Q" variable to search for the option selected
     *
     * @param item MenuItem object representing the item selected
     * @return true if the event was successful
     */
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // switch statement to determine which menu item was selected using its id
        switch (item.getItemId()) {
            case R.id.f1:
                Toast.makeText(this, "All F1 Headlines Showing", Toast.LENGTH_SHORT).show();
                Q = "F1";
                recreate();

                return true;

            case R.id.merc:
                Toast.makeText(this, "Showing Mercedes Headlines First", Toast.LENGTH_SHORT).show();
                Q = "mercedes";
                recreate();

                return true;

            case R.id.redbull:
                Toast.makeText(this, "Showing Redbull Headlines First", Toast.LENGTH_SHORT).show();
                Q = "redbull";
                recreate();

                return true;

            case R.id.ferrari:
                Toast.makeText(this, "Showing Ferrari Headlines First", Toast.LENGTH_SHORT).show();
                Q = "ferrari";
                recreate();

                return true;

            case R.id.alpine:
                Toast.makeText(this, "Showing Alpine Headlines First", Toast.LENGTH_SHORT).show();
                Q = "alpine";
                recreate();

                return true;

            case R.id.am:
                Toast.makeText(this, "Showing Aston Martin Headlines First", Toast.LENGTH_SHORT).show();
                Q = "aston martin";
                recreate();

                return true;

            case R.id.ar:
                Toast.makeText(this, "Showing Alfa Romeo Headlines First", Toast.LENGTH_SHORT).show();
                Q = "alfa romeo";
                recreate();

                return true;

            case R.id.at:
                Toast.makeText(this, "Showing Alpha Tauri Headlines First", Toast.LENGTH_SHORT).show();
                Q = "alfa tauri";
                recreate();

                return true;

            case R.id.williams:
                Toast.makeText(this, "Showing Williams Headlines First", Toast.LENGTH_SHORT).show();
                Q = "williams";
                recreate();

                return true;

            case R.id.mclaren:
                Toast.makeText(this, "Showing McLaren Headlines First", Toast.LENGTH_SHORT).show();
                Q = "mclaren";
                recreate();

                return true;

            case R.id.haas:
                Toast.makeText(this, "Showing Haas Headlines First", Toast.LENGTH_SHORT).show();
                Q = "haas";
                recreate();

                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This is called when an article is clicked, then opens the article url in webActivity using an
     * intent
     *
     * @param view The View object representing the clicked item in the RecyclerView
     */
    @Override
    public void onItemClick(View view) {
        if (view.getId() == R.id.article_adapter_ll_parent) {
            // gets the article associated with the clicked card
            Article article = (Article) view.getTag();
            if (!TextUtils.isEmpty(article.getUrl())) {
                Intent webActivity = new Intent(this, ArticleViewer.class);
                // puts the article url as an extra in the intent
                webActivity.putExtra("url", article.getUrl());
                startActivity(webActivity);
            }
        }
    }

    /**
     *
     * @param view the View object representing the checkable UI component that triggered the event
     */
    @Override
    public void onCheckedChanged(View view) {
        // TODO: is this still needed
    }


}
